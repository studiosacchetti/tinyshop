<div class="clearfix space70"></div>
<!-- FOOTER -->
<footer id="footer2">

    <div class="footer-bottom container">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; Copyright 2020. My comany</p>
            </div>
            <div class="col-md-6">

            </div>
        </div>
    </div>
</footer>
<!-- FOOTER -->
</div>


<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/dialogFx.js"></script>
<script src="js/dialog-js.js"></script>
<script src="vendor/navigation/jquery.easing.js"></script>
<script src="vendor/flexslider/jquery.flexslider.js"></script>
<script src="vendor/navigation/scroll.js"></script>
<script src="vendor/navigation/jquery.sticky.js"></script>
<script src="vendor/owl-carousel/owl.carousel.min.js"></script>
<script src="vendor/isotope/isotope.pkgd.js"></script>
<script src="vendor/superfish/js/hoverIntent.js"></script>
<script src="vendor/superfish/js/superfish.js"></script>
<script src="js/tweecool.js"></script>
<script src="js/jquery.bpopup.js"></script>
<script src="vendor/pikaday/pikaday.js"></script>
<script src="js/classie.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>   
<script src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.prettyphoto.js"></script>
<script src="js/script.js"></script>
<script src="js/booking.js"></script>



</body>
</html>